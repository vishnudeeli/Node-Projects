﻿namespace potluck_backend_dotnet.Data
{
    public class AddPotluckRequest
    {
        public string EmpName { get; set; }
        public string EmpId { get; set; }
        public string DishName { get; set; }
        public string DishUrl { get; set; }
        public string Description { get; set; }
    }
}

