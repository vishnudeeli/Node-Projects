<!-- <template>
  <div class="about">
    <img src="https://ts-production.imgix.net/images/2089ea9d-feba-4097-aaed-c8acaa2e3ad3.jpg?auto=compress,format&w=800&h=450" style="width: 100%; height: 100%;"/>
  <img src="https://blog.vantagecircle.com/content/images/2022/09/christmas-potluck-ideas-for-work.png" style="width: 100%; height: 100%;"/>
  </div>
</template> -->

<template>
  <div class="potluck-container">
    <h1>Welcome to potluck event</h1>
  </div>
</template>

<style>
.potluck-container {
  background-image: url('https://ts-production.imgix.net/images/2089ea9d-feba-4097-aaed-c8acaa2e3ad3.jpg?auto=compress,format&w=800&h=450');
  background-size: cover;
  background-position: center;
  height: 100vh;
  display: flex;
  justify-content: center;
  
}

h1 {
  color: rgb(15, 1, 1);
  font-size: 4rem;
  text-align: center;
}
</style>
