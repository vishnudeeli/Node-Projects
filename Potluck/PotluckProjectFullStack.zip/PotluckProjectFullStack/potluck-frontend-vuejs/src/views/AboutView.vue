<template>
  <div class="about-page">
    <div class="page-header">
      <h1>About Potluck</h1>
      <img src="https://cdn.dribbble.com/users/32287/screenshots/2694924/potluck-dribbble.png?compress=1&resize=400x300&vertical=top" alt="Potluck logo" />
    </div>
    <div class="page-content">
      <h2>Our Mission</h2>
      <p>We believe that food brings people together, and Potluck is all about sharing that experience. Our mission is to provide a platform for people to share their love of food and connect with others.</p>

      <h2>Our Story</h2>
      <p>Potluck was founded in 2020 by a group of food lovers who wanted to create a space where people could share their favorite recipes, tips, and stories. Since then, we've grown to a community of over 10,000 members and counting!</p>

      
    </div>
  </div>
</template>


<style>
.about-page {
  max-width: 800px;
  margin: 0 auto;
  padding: 40px;
}

.page-header {
  display: flex;
  align-items: center;
}

.page-header h1 {
  margin-right: 20px;
}

.page-header img {
  width: 100px;
  height: 100px;
}

.page-content h2 {
  margin-top: 40px;
  margin-bottom: 20px;
}

.team-member {
  display: flex;
  align-items: center;
  margin-top: 20px;
}

.team-member img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-right: 20px;
}
</style>
